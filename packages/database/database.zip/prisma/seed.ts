import {
  BillingCycle,
  DomainEventType,
  MembershipRole,
  NotificationChannel,
  PlatformPlanStatus,
  PlatformRole,
  PrismaClient,
  RegistryStatus,
  StudentDocumentType,
  StudentProcessStatus,
  TenantStatus,
  TenantSubscriptionStatus,
  Weekday,
} from "@prisma/client";
import { compare, hash } from "bcrypt";

const prisma = new PrismaClient();

const DEMO_TENANT_SLUG = "autoescola-demonstracao";
const DEMO_ADMIN_EMAIL = "admin@prumo.local";
const PLATFORM_OWNER_EMAIL = "platform@prumo.local";
const DEVELOPMENT_PASSWORD = "PrumoDev@123";

const TEMPLATE_CODES = [
  "user-invited",
  "student-created",
  "process-created",
  "process-stage-completed",
  "document-approved",
  "document-rejected",
  "practical-lesson-created",
  "practical-lesson-rescheduled",
  "practical-lesson-cancelled",
  "practical-lesson-completed",
  "practical-lesson-reminder",
  "theoretical-class-created",
  "theoretical-class-updated",
  "theoretical-class-cancelled",
  "theoretical-class-reminder",
  "exam-scheduled",
  "exam-rescheduled",
  "exam-cancelled",
  "exam-result",
  "exam-reminder",
  "contract-activated",
  "installment-created",
  "installment-due-soon",
  "installment-overdue",
  "payment-confirmed",
  "payment-refunded",
  "document-expiring",
  "process-expiring",
] as const;

const TEMPLATE_LABELS: Partial<
  Record<(typeof TEMPLATE_CODES)[number], string>
> = {
  "practical-lesson-created": "Aula prática criada",
  "practical-lesson-rescheduled": "Aula prática reagendada",
  "practical-lesson-cancelled": "Aula prática cancelada",
  "practical-lesson-reminder": "Lembrete de aula prática",
  "theoretical-class-reminder": "Lembrete de turma teórica",
  "exam-scheduled": "Exame agendado",
  "exam-rescheduled": "Exame reagendado",
  "exam-result": "Resultado de exame disponível",
  "exam-reminder": "Lembrete de exame",
  "installment-due-soon": "Parcela próxima do vencimento",
  "installment-overdue": "Parcela vencida",
  "payment-confirmed": "Pagamento confirmado",
  "document-rejected": "Documento rejeitado",
  "process-expiring": "Processo próximo do vencimento",
};

function getRounds(): number {
  const rounds = Number(process.env.BCRYPT_ROUNDS ?? 12);

  if (!Number.isInteger(rounds) || rounds < 10 || rounds > 15) {
    throw new Error("BCRYPT_ROUNDS deve ser um inteiro entre 10 e 15.");
  }

  return rounds;
}

async function seed(): Promise<void> {
  const configuredPassword = process.env.SEED_ADMIN_PASSWORD;

  if (process.env.NODE_ENV === "production" && !configuredPassword) {
    throw new Error(
      "SEED_ADMIN_PASSWORD é obrigatório para executar o seed em produção.",
    );
  }
  const configuredPlatformPassword = process.env.SEED_PLATFORM_PASSWORD;
  if (process.env.NODE_ENV === "production" && !configuredPlatformPassword) {
    throw new Error(
      "SEED_PLATFORM_PASSWORD é obrigatório para criar o proprietário global em produção.",
    );
  }

  const password = configuredPassword ?? DEVELOPMENT_PASSWORD;
  const platformPassword = configuredPlatformPassword ?? DEVELOPMENT_PASSWORD;
  const licenseCategories = [
    {
      code: "ACC",
      name: "Autorização para Conduzir Ciclomotor",
      description: "Categoria para ciclomotores.",
    },
    {
      code: "A",
      name: "Categoria A",
      description: "Veículos de duas ou três rodas.",
    },
    {
      code: "B",
      name: "Categoria B",
      description: "Automóveis e utilitários leves.",
    },
    { code: "C", name: "Categoria C", description: "Veículos de carga." },
    { code: "D", name: "Categoria D", description: "Veículos de passageiros." },
    { code: "E", name: "Categoria E", description: "Combinações de veículos." },
  ];
  for (const category of licenseCategories) {
    await prisma.licenseCategory.upsert({
      where: { code: category.code },
      create: { ...category, active: true },
      update: { ...category, active: true },
    });
  }

  const tenant = await prisma.tenant.upsert({
    where: { slug: DEMO_TENANT_SLUG },
    create: {
      name: "Autoescola Demonstração",
      slug: DEMO_TENANT_SLUG,
      status: TenantStatus.ACTIVE,
    },
    update: {
      name: "Autoescola Demonstração",
      status: TenantStatus.ACTIVE,
    },
  });

  const suspendedTenant = await prisma.tenant.upsert({
    where: { slug: "autoescola-horizonte" },
    create: {
      name: "Autoescola Horizonte",
      slug: "autoescola-horizonte",
      document: "98765432000110",
      status: TenantStatus.SUSPENDED,
      suspendedAt: new Date(),
      suspensionReason: "Tenant de demonstração para validação do console.",
    },
    update: {
      name: "Autoescola Horizonte",
      status: TenantStatus.SUSPENDED,
      suspendedAt: new Date(),
      suspensionReason: "Tenant de demonstração para validação do console.",
    },
  });

  const basicPlan = await prisma.platformPlan.upsert({
    where: { code: "BASIC" },
    create: {
      code: "BASIC",
      name: "Prumo Básico",
      description: "Plano inicial para autoescolas de pequeno porte.",
      status: PlatformPlanStatus.ACTIVE,
      monthlyPriceCents: 19900,
      annualPriceCents: 199000,
      maxUsers: 10,
      maxStudents: 300,
      maxUnits: 1,
      maxStorageBytes: BigInt(5 * 1024 * 1024 * 1024),
      features: {
        FINANCIAL: true,
        MOBILE_APP: true,
        NOTIFICATIONS: true,
        MULTI_UNIT: false,
        ADVANCED_REPORTS: false,
        CUSTOM_BRANDING: false,
        API_ACCESS: false,
      },
    },
    update: {
      name: "Prumo Básico",
      status: PlatformPlanStatus.ACTIVE,
      monthlyPriceCents: 19900,
    },
  });
  const proPlan = await prisma.platformPlan.upsert({
    where: { code: "PRO" },
    create: {
      code: "PRO",
      name: "Prumo Pro",
      description: "Plano completo com múltiplas unidades e relatórios.",
      status: PlatformPlanStatus.ACTIVE,
      monthlyPriceCents: 49900,
      annualPriceCents: 499000,
      maxUsers: 50,
      maxStudents: 2000,
      maxUnits: 10,
      maxStorageBytes: BigInt(50 * 1024 * 1024 * 1024),
      features: {
        FINANCIAL: true,
        MOBILE_APP: true,
        NOTIFICATIONS: true,
        MULTI_UNIT: true,
        ADVANCED_REPORTS: true,
        CUSTOM_BRANDING: true,
        API_ACCESS: true,
      },
    },
    update: {
      name: "Prumo Pro",
      status: PlatformPlanStatus.ACTIVE,
      monthlyPriceCents: 49900,
    },
  });

  await Promise.all([
    prisma.tenantSettings.upsert({
      where: { tenantId: tenant.id },
      create: { tenantId: tenant.id },
      update: {},
    }),
    prisma.tenantSettings.upsert({
      where: { tenantId: suspendedTenant.id },
      create: { tenantId: suspendedTenant.id },
      update: {},
    }),
    prisma.tenantFinancialSettings.upsert({
      where: { tenantId: suspendedTenant.id },
      create: { tenantId: suspendedTenant.id },
      update: {},
    }),
    prisma.platformSetting.upsert({
      where: { key: "support.maxDurationMinutes" },
      create: {
        key: "support.maxDurationMinutes",
        value: 30,
        description: "Duração máxima da sessão de suporte em minutos.",
      },
      update: { value: 30 },
    }),
    prisma.platformSetting.upsert({
      where: { key: "security.globalMfaRecommended" },
      create: {
        key: "security.globalMfaRecommended",
        value: true,
        description: "Recomenda MFA para todos os papéis globais.",
      },
      update: { value: true },
    }),
  ]);

  async function ensureSubscription(
    tenantId: string,
    planId: string,
    status: TenantSubscriptionStatus,
  ): Promise<void> {
    const existing = await prisma.tenantSubscription.findFirst({
      where: { tenantId, planId },
      orderBy: { createdAt: "asc" },
    });
    const startsAt = new Date("2026-01-01T00:00:00.000Z");
    const currentPeriodStartsAt = new Date(
      Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1),
    );
    const currentPeriodEndsAt = new Date(
      Date.UTC(
        currentPeriodStartsAt.getUTCFullYear(),
        currentPeriodStartsAt.getUTCMonth() + 1,
        1,
      ),
    );
    const data = {
      status,
      billingCycle: BillingCycle.MONTHLY,
      startsAt,
      currentPeriodStartsAt,
      currentPeriodEndsAt,
    };
    if (existing) {
      await prisma.tenantSubscription.update({
        where: { id: existing.id },
        data,
      });
    } else {
      await prisma.tenantSubscription.create({
        data: { tenantId, planId, ...data },
      });
    }
  }
  await ensureSubscription(
    tenant.id,
    proPlan.id,
    TenantSubscriptionStatus.ACTIVE,
  );
  await ensureSubscription(
    suspendedTenant.id,
    basicPlan.id,
    TenantSubscriptionStatus.SUSPENDED,
  );
  await prisma.tenant.update({
    where: { id: tenant.id },
    data: { planCode: proPlan.code },
  });
  await prisma.tenant.update({
    where: { id: suspendedTenant.id },
    data: { planCode: basicPlan.code },
  });

  const existingPlatformOwner = await prisma.user.findUnique({
    where: { email: PLATFORM_OWNER_EMAIL },
  });
  const platformPasswordMatches = existingPlatformOwner
    ? await compare(platformPassword, existingPlatformOwner.passwordHash)
    : false;
  const platformPasswordHash =
    existingPlatformOwner && platformPasswordMatches
      ? existingPlatformOwner.passwordHash
      : await hash(platformPassword, getRounds());
  await prisma.user.upsert({
    where: { email: PLATFORM_OWNER_EMAIL },
    create: {
      name: "Proprietário da Plataforma",
      email: PLATFORM_OWNER_EMAIL,
      passwordHash: platformPasswordHash,
      passwordSetAt: new Date(),
      active: true,
      platformRole: PlatformRole.PLATFORM_OWNER,
      communicationSettings: { create: {} },
    },
    update: {
      name: "Proprietário da Plataforma",
      passwordHash: platformPasswordHash,
      passwordSetAt: new Date(),
      active: true,
      platformRole: PlatformRole.PLATFORM_OWNER,
    },
  });

  const seededTemplates = new Map<string, string>();
  for (const code of TEMPLATE_CODES) {
    for (const channel of [
      NotificationChannel.IN_APP,
      NotificationChannel.EMAIL,
      NotificationChannel.PUSH,
    ]) {
      const label =
        TEMPLATE_LABELS[code] ??
        code
          .split("-")
          .map((part) => part[0].toUpperCase() + part.slice(1))
          .join(" ");
      const existing = await prisma.notificationTemplate.findFirst({
        where: { tenantId: null, code, channel, version: 1 },
      });
      const values = {
        subject:
          channel === NotificationChannel.EMAIL ? `Prumo | ${label}` : null,
        title: channel !== NotificationChannel.EMAIL ? label : null,
        body:
          channel === NotificationChannel.EMAIL
            ? `Olá, {{userName}}. <p>${label} na {{tenantName}}.</p><p>Acesse: {{actionUrl}}</p>`
            : `Olá, {{userName}}. ${label} na {{tenantName}}.`,
        allowedVariables: ["userName", "tenantName", "actionUrl", "eventType"],
        active: true,
      };
      const template = existing
        ? await prisma.notificationTemplate.update({
            where: { id: existing.id },
            data: values,
          })
        : await prisma.notificationTemplate.create({
            data: {
              tenantId: null,
              code,
              channel,
              version: 1,
              ...values,
            },
          });
      seededTemplates.set(`${code}:${channel}`, template.id);
    }
  }

  const reminderDefaults = [
    [
      DomainEventType.PRACTICAL_LESSON_CREATED,
      24 * 60,
      "practical-lesson-reminder",
    ],
    [
      DomainEventType.PRACTICAL_LESSON_CREATED,
      2 * 60,
      "practical-lesson-reminder",
    ],
    [
      DomainEventType.THEORETICAL_CLASS_CREATED,
      24 * 60,
      "theoretical-class-reminder",
    ],
    [DomainEventType.EXAM_SCHEDULED, 48 * 60, "exam-reminder"],
    [DomainEventType.INSTALLMENT_CREATED, 3 * 24 * 60, "installment-due-soon"],
    [DomainEventType.PROCESS_CREATED, 30 * 24 * 60, "process-expiring"],
  ] as const;
  for (const [eventType, minutesBefore, templateCode] of reminderDefaults) {
    const templateId = seededTemplates.get(
      `${templateCode}:${NotificationChannel.IN_APP}`,
    );
    if (!templateId) continue;
    await prisma.reminderRule.upsert({
      where: {
        tenantId_eventType_channel_minutesBefore: {
          tenantId: tenant.id,
          eventType,
          channel: NotificationChannel.IN_APP,
          minutesBefore,
        },
      },
      create: {
        tenantId: tenant.id,
        eventType,
        channel: NotificationChannel.IN_APP,
        minutesBefore,
        templateId,
        active: true,
      },
      update: { templateId },
    });
  }

  const existingUser = await prisma.user.findUnique({
    where: { email: DEMO_ADMIN_EMAIL },
  });
  const passwordMatches = existingUser
    ? await compare(password, existingUser.passwordHash)
    : false;
  const passwordHash =
    existingUser && passwordMatches
      ? existingUser.passwordHash
      : await hash(password, getRounds());

  const user = await prisma.user.upsert({
    where: { email: DEMO_ADMIN_EMAIL },
    create: {
      name: "Administrador Prumo",
      email: DEMO_ADMIN_EMAIL,
      passwordHash,
      passwordSetAt: new Date(),
      active: true,
    },
    update: {
      name: "Administrador Prumo",
      passwordHash,
      passwordSetAt: new Date(),
      active: true,
    },
  });

  await prisma.membership.upsert({
    where: {
      tenantId_userId: {
        tenantId: tenant.id,
        userId: user.id,
      },
    },
    create: {
      tenantId: tenant.id,
      userId: user.id,
      role: MembershipRole.TENANT_OWNER,
      active: true,
    },
    update: {
      role: MembershipRole.TENANT_OWNER,
      active: true,
    },
  });

  const student = await prisma.student.upsert({
    where: {
      tenantId_cpf: {
        tenantId: tenant.id,
        cpf: "52998224725",
      },
    },
    create: {
      tenantId: tenant.id,
      name: "Mariana Souza",
      cpf: "52998224725",
      email: "mariana@exemplo.local",
      phone: "(11) 99999-0101",
      status: RegistryStatus.ACTIVE,
    },
    update: {
      name: "Mariana Souza",
      email: "mariana@exemplo.local",
      phone: "(11) 99999-0101",
      status: RegistryStatus.ACTIVE,
    },
  });

  const studentUser = await prisma.user.upsert({
    where: { email: "mariana@exemplo.local" },
    create: {
      name: "Mariana Souza",
      email: "mariana@exemplo.local",
      passwordHash,
      passwordSetAt: new Date(),
      active: true,
    },
    update: {
      name: "Mariana Souza",
      passwordHash,
      passwordSetAt: new Date(),
      active: true,
    },
  });
  await prisma.membership.upsert({
    where: {
      tenantId_userId: { tenantId: tenant.id, userId: studentUser.id },
    },
    create: {
      tenantId: tenant.id,
      userId: studentUser.id,
      role: MembershipRole.STUDENT,
      active: true,
    },
    update: { role: MembershipRole.STUDENT, active: true },
  });
  await prisma.student.update({
    where: { id: student.id },
    data: { userId: studentUser.id },
  });

  await prisma.studentAddress.upsert({
    where: {
      studentId_tenantId: {
        studentId: student.id,
        tenantId: tenant.id,
      },
    },
    create: {
      tenantId: tenant.id,
      studentId: student.id,
      zipCode: "01310100",
      street: "Avenida Paulista",
      number: "1000",
      neighborhood: "Bela Vista",
      city: "São Paulo",
      state: "SP",
    },
    update: {
      zipCode: "01310100",
      street: "Avenida Paulista",
      number: "1000",
      neighborhood: "Bela Vista",
      city: "São Paulo",
      state: "SP",
    },
  });

  await prisma.studentDocument.upsert({
    where: {
      tenantId_studentId_type_number: {
        tenantId: tenant.id,
        studentId: student.id,
        type: StudentDocumentType.RG,
        number: "123456789",
      },
    },
    create: {
      tenantId: tenant.id,
      studentId: student.id,
      type: StudentDocumentType.RG,
      number: "123456789",
      issuingAuthority: "SSP/SP",
    },
    update: {
      issuingAuthority: "SSP/SP",
    },
  });

  const demoProcess = await prisma.studentProcess.findFirst({
    where: {
      tenantId: tenant.id,
      studentId: student.id,
      renach: "DEMO000001",
    },
  });
  if (demoProcess) {
    await prisma.studentProcess.update({
      where: { id: demoProcess.id },
      data: {
        category: "B",
        status: StudentProcessStatus.IN_PROGRESS,
      },
    });
  } else {
    await prisma.studentProcess.create({
      data: {
        tenantId: tenant.id,
        studentId: student.id,
        category: "B",
        renach: "DEMO000001",
        status: StudentProcessStatus.IN_PROGRESS,
      },
    });
  }

  const instructor = await prisma.instructor.upsert({
    where: {
      tenantId_cpf: {
        tenantId: tenant.id,
        cpf: "11144477735",
      },
    },
    create: {
      tenantId: tenant.id,
      name: "Carlos Oliveira",
      cpf: "11144477735",
      email: "carlos@exemplo.local",
      phone: "(11) 99999-0202",
      license: "01234567890",
      licenseCategory: "AB",
      credentialNumber: "INSTR-DEMO-01",
      status: RegistryStatus.ACTIVE,
    },
    update: {
      name: "Carlos Oliveira",
      status: RegistryStatus.ACTIVE,
    },
  });

  const instructorUser = await prisma.user.upsert({
    where: { email: "carlos@exemplo.local" },
    create: {
      name: "Carlos Oliveira",
      email: "carlos@exemplo.local",
      passwordHash,
      passwordSetAt: new Date(),
      active: true,
    },
    update: {
      name: "Carlos Oliveira",
      passwordHash,
      passwordSetAt: new Date(),
      active: true,
    },
  });
  await prisma.membership.upsert({
    where: {
      tenantId_userId: { tenantId: tenant.id, userId: instructorUser.id },
    },
    create: {
      tenantId: tenant.id,
      userId: instructorUser.id,
      role: MembershipRole.INSTRUCTOR,
      active: true,
    },
    update: { role: MembershipRole.INSTRUCTOR, active: true },
  });
  await prisma.instructor.update({
    where: { id: instructor.id },
    data: { userId: instructorUser.id },
  });

  await prisma.vehicle.upsert({
    where: {
      tenantId_plate: {
        tenantId: tenant.id,
        plate: "PRM1A23",
      },
    },
    create: {
      tenantId: tenant.id,
      plate: "PRM1A23",
      brand: "Volkswagen",
      model: "Polo",
      year: 2025,
      color: "Branco",
      renavam: "12345678901",
      category: "B",
      status: RegistryStatus.ACTIVE,
    },
    update: {
      brand: "Volkswagen",
      model: "Polo",
      year: 2025,
      status: RegistryStatus.ACTIVE,
    },
  });

  const unit = await prisma.schoolUnit.upsert({
    where: {
      tenantId_name: {
        tenantId: tenant.id,
        name: "Unidade Centro",
      },
    },
    create: {
      tenantId: tenant.id,
      name: "Unidade Centro",
      document: "12345678000199",
      phone: "(11) 3333-0101",
      email: "centro@prumo.local",
      address: "Avenida Paulista, 1000 - Bela Vista, São Paulo/SP",
      openingTime: "07:00",
      closingTime: "22:00",
      active: true,
    },
    update: {
      document: "12345678000199",
      phone: "(11) 3333-0101",
      email: "centro@prumo.local",
      address: "Avenida Paulista, 1000 - Bela Vista, São Paulo/SP",
      openingTime: "07:00",
      closingTime: "22:00",
      active: true,
    },
  });

  await prisma.tenantFinancialSettings.upsert({
    where: { tenantId: tenant.id },
    create: {
      tenantId: tenant.id,
      autoChargeExamRetest: false,
      autoChargeExtraLesson: false,
      blockSchedulingWithDebt: false,
      debtToleranceCents: 0,
      requireOpenCashRegisterForCashPayment: true,
      defaultFinePercentageBasisPoints: 200,
      defaultMonthlyInterestBasisPoints: 100,
    },
    update: {},
  });

  await prisma.classroom.upsert({
    where: {
      tenantId_unitId_name: {
        tenantId: tenant.id,
        unitId: unit.id,
        name: "Sala Teórica 1",
      },
    },
    create: {
      tenantId: tenant.id,
      unitId: unit.id,
      name: "Sala Teórica 1",
      capacity: 30,
      active: true,
    },
    update: {
      capacity: 30,
      active: true,
    },
  });

  const weekdays = [
    Weekday.MONDAY,
    Weekday.TUESDAY,
    Weekday.WEDNESDAY,
    Weekday.THURSDAY,
    Weekday.FRIDAY,
    Weekday.SATURDAY,
  ];
  for (const weekday of weekdays) {
    await prisma.instructorAvailability.upsert({
      where: {
        tenantId_instructorId_weekday_startsAt_endsAt: {
          tenantId: tenant.id,
          instructorId: instructor.id,
          weekday,
          startsAt: "07:00",
          endsAt: "22:00",
        },
      },
      create: {
        tenantId: tenant.id,
        instructorId: instructor.id,
        weekday,
        startsAt: "07:00",
        endsAt: "22:00",
        active: true,
      },
      update: { active: true },
    });
  }

  console.log(`Seed concluído: ${DEMO_ADMIN_EMAIL} e ${PLATFORM_OWNER_EMAIL}.`);
}

seed()
  .catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
